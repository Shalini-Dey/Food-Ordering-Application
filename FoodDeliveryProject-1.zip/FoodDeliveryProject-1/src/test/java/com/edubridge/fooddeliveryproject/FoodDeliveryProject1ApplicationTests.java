package com.edubridge.fooddeliveryproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodDeliveryProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
