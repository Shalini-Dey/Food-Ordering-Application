package com.edubridge.fooddeliveryproject.service;

import java.util.List;

//import javax.validation.Valid;

import com.edubridge.fooddeliveryproject.model.Order;

public interface OrderService {

	Order saveOrder(Order order,String userEmailId);

	List<Order> getOrder();

	Order getOrderById(long orderId);

	void deleteOrderById(long orderId);

	List<Order> getOrderByUserEmailID(String userEmailId);

}
