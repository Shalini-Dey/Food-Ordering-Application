package com.edubridge.fooddeliveryproject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edubridge.fooddeliveryproject.model.Cart;

public interface CartRepository extends JpaRepository<Cart, Long>{
	
	List<Cart> findByUserEmailID(String userEmailID);
}
