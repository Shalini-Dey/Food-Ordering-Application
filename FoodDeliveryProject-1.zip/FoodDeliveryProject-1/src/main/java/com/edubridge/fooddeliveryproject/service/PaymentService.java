package com.edubridge.fooddeliveryproject.service;

import java.util.List;

import com.edubridge.fooddeliveryproject.model.Payment;

public interface PaymentService {

	Payment addPayment(Payment payment, long orderId, String userEmailId);
	

	List<Payment> getAllPayments();

	void deletePayment(long paymentId);

	Payment getPaymentById(long paymentId);

	List<Payment> getPaymentByUserEmailId(String userEmailId);

}
