package com.edubridge.fooddeliveryproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodDeliveryProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(FoodDeliveryProject1Application.class, args);
	}

}
