package com.edubridge.fooddeliveryproject.serviceimpl;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.edubridge.fooddeliveryproject.exception.UserNotFoundException;
import com.edubridge.fooddeliveryproject.model.Cart;
import com.edubridge.fooddeliveryproject.model.Food;
import com.edubridge.fooddeliveryproject.model.Order;
import com.edubridge.fooddeliveryproject.model.User;
import com.edubridge.fooddeliveryproject.repository.OrderRepository;
import com.edubridge.fooddeliveryproject.service.CartService;
import com.edubridge.fooddeliveryproject.service.FoodService;
import com.edubridge.fooddeliveryproject.service.OrderService;
import com.edubridge.fooddeliveryproject.service.UserService;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository orderRepository;
	private CartService cartService;
	private FoodService foodService;
	private UserService userService;
	
	public OrderServiceImpl(OrderRepository orderRepository, CartService cartService, FoodService foodService,
			UserService userService) {
		super();
		this.orderRepository = orderRepository;
		this.cartService = cartService;
		this.foodService = foodService;
		this.userService = userService;
	}


	@Override
	public Order saveOrder(Order order,String userEmailId) {
		// TODO Auto-generated method stub
		float total=0.0f;
		User user=userService.getUserByEmailID(userEmailId);
		System.out.println("1111");
		List<Cart> cartList= cartService.getCartByUserEmailId(userEmailId);
		for(Cart cart:cartList){
			Food food=foodService.getFoodById(cart.getFood().foodId);
			total=total+(food.price*cart.getQuantity());
			System.out.println("2222");
		}
		order.setTotal(total);
		order.setUser(user);
		System.out.println(total + "            " +user );
		//Order order1 = orderRepository.findByTotalAndUserEmailID(total,userEmailId);
		//if(order1.equals(null) ) {
			
			//System.out.println("3333");
		
		return orderRepository.save(order);
		} 
	/*	else {
			System.out.println("44444");
			return null;
		} */
	
	@Override
	public List<Order> getOrder() {
		// TODO Auto-generated method stub
		return orderRepository.findAll();
	}


	@Override
	public Order getOrderById(long orderId) {
		// TODO Auto-generated method stub
		return orderRepository.findById(orderId).orElseThrow(()-> new UserNotFoundException("Order", "OrderId", orderId));
	}


	@Override
	public void deleteOrderById(long orderId) {
		// TODO Auto-generated method stub
		orderRepository.findById(orderId).orElseThrow(()-> new UserNotFoundException("Order", "OrderId", orderId));
		orderRepository.deleteById(orderId);
	}
	@Override
	public List<Order> getOrderByUserEmailID(String userEmailId) {
		// TODO Auto-generated method stub
		return orderRepository.findByUserEmailID(userEmailId);
		 
	}
}
	


