  package com.edubridge.fooddeliveryproject.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="cart_Table")
public class Cart {
	@Id
	@Column(name="cart_Id")
	@GeneratedValue(generator = "seqc", strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name="seqc", initialValue = 100)
	public long cartId;
	
	@Column(name = "quantity")
	public long quantity;
	
	/*@Column(name = "food_Id")
	public long foodId;
	
	@Column(name = "email_Id")
	@NotEmpty
	@Email(message="Email  is not valid!")
	public String emailID;*/
	
	public Cart()
	{
	
	}

	/* @OneToOne
	@JoinColumn(name="OrderId")
	Order order;
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	*/
	@ManyToOne( cascade=CascadeType.MERGE)
	@JoinColumn(name="foodId")
	@JsonIgnore
	@OnDelete(action=OnDeleteAction.CASCADE)
	private Food food;
	
	@ManyToOne( cascade=CascadeType.MERGE)
	@JoinColumn(name="userEmailId")
	@JsonIgnore
	@OnDelete(action=OnDeleteAction.CASCADE)
	private User user;
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public long getCartId() {
		return cartId;
	}

	public void setCartId(long cartId) {
		this.cartId = cartId;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public Food getFood() {
		return food;
	}

	public void setFood(Food food) {
		this.food = food;
	}

	
	public Cart(long cartId,long quantity,Food food) {
		super();
		this.cartId = cartId;
		this.quantity = quantity;
		this.food =food;
	}
	
	
	
}
