package com.edubridge.fooddeliveryproject.repository;

import java.util.List;

//import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edubridge.fooddeliveryproject.model.Cart;

public interface CartRepository extends JpaRepository<Cart, Long>{
	
	List<Cart> findByUserEmailID(String userEmailID);
	//Cart findByFoodFoodIdAndUserEmailId(long foodId,String userEmailId);
	//@Transactional

	void deleteByUserEmailID(String userEmailId);
}
