package com.edubridge.fooddeliveryproject.serviceimpl;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.fooddeliveryproject.exception.UserNotFoundException;
import com.edubridge.fooddeliveryproject.model.Order;
import com.edubridge.fooddeliveryproject.model.Payment;
import com.edubridge.fooddeliveryproject.model.User;
import com.edubridge.fooddeliveryproject.repository.PaymentRepository;
import com.edubridge.fooddeliveryproject.service.OrderService;
import com.edubridge.fooddeliveryproject.service.PaymentService;
import com.edubridge.fooddeliveryproject.service.UserService;

@Service
public class PaymentServiceImpl implements PaymentService{

	@Autowired
	private PaymentRepository paymentRepository;
	private UserService userService;
	private OrderService orderService;
	
	public PaymentServiceImpl(PaymentRepository paymentRepository,UserService userService,OrderService orderService) {
		super();
		this.paymentRepository = paymentRepository;
		this.userService = userService;
		this.orderService = orderService;
		
	}

	@Override
	public Payment addPayment(Payment payment, long orderId, String userEmailId) {
		// TODO Auto-generated method stub
		Date d = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
		String str = formatter.format(d);
		payment.setPaidDate(str);
		
		System.out.println("Service" + orderId);
		Order order=orderService.getOrderById(orderId);
		User user=userService.getUserByEmailID(userEmailId);
		payment.setOrder(order);
		payment.setUser(user);
		payment.setTotalPrice(order.getTotal());
		return paymentRepository.save(payment);	
		
	}

	@Override
	public List<Payment> getAllPayments() {
		// TODO Auto-generated method stub
		return paymentRepository.findAll();
	}

	@Override
	public void deletePayment(long paymentId) {
		// TODO Auto-generated method stub
		paymentRepository.findById(paymentId).orElseThrow(()->new UserNotFoundException("Payment","PaymentId",paymentId)); 
		paymentRepository.deleteById(paymentId);

	}

	@Override
	public Payment getPaymentById(long paymentId) {
		// TODO Auto-generated method stub
		return paymentRepository.findById(paymentId).orElseThrow(()->new UserNotFoundException("Payment","PaymentId",paymentId)); 
	}

	@Override
	public List<Payment> getPaymentByUserEmailId(String userEmailId) {
		// TODO Auto-generated method stub
		return paymentRepository.findByUserEmailID(userEmailId);
	}

}