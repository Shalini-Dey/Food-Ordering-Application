package com.edubridge.fooddeliveryproject;

//import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.assertj.core.api.Assertions;

//import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.edubridge.fooddeliveryproject.model.Category;
//import com.edubridge.fooddeliveryproject.model.User;
import com.edubridge.fooddeliveryproject.repository.CategoryRepository;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class CategoryTestCase {
	@Autowired
	CategoryRepository categoryRepository;

	@Test
	@Order(1)
	public void updateCategoryById()
	{
		Category category = categoryRepository.findById(1001L).get();
		category.setCategoryName("Pizza Corner");
		Category categoryUpdated = categoryRepository.save(category);
		Assertions.assertThat(categoryUpdated.getCategoryName()).isEqualTo("Pizza Corner");
	}
	
	

	@Test
	@Order(2)
	public void getCategoryById()
	{
		Category category = categoryRepository.findById(1000L).get();
		Assertions.assertThat(category.getCategoryId()).isEqualTo(1000L);
	}


	

}
