package com.edubridge.fooddeliveryproject;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.assertj.core.api.Assertions;
//import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
//import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;

import com.edubridge.fooddeliveryproject.model.User;
import com.edubridge.fooddeliveryproject.repository.UserRepository;

@SpringBootTest
//@TestMethodOrder(MethodOrder.OrderAnnotation.class)
class UserTestCase {
	
	@Autowired
	UserRepository userRepository;

	@Test
	public void saveUser()
	{
		User user = new User();
		user.setEmailID("Tony@gmail.com");
		user.setFirstName("Tony");
		user.setLastName("Stark");
		user.setPassword("Tony@123");
		user.setDistrict("Dhanbad");
		user.setState("Jharkhand");
		user.setStreet("Pasreecha Market");
		user.setZipCode("828121");
		user.setMobile_No("7897897897");
		user.setRole("user");
		userRepository.save(user);
		assertNotNull(userRepository.findByEmailID("Tony@gmail.com").get());
	}
	
	@Test
	public void getUserByEmailID() {
		User user = userRepository.findByEmailID("Tony@gmail.com").get();
		Assertions.assertThat(user.getEmailID().isBlank());
	}
	
	@Test
	public void testReadAll() {
		List<User> list =userRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
		}

	
	@Test
	public void deleteUser()
	{
	    userRepository.deleteByEmailID("p@gmail.com");	
	    assertNotNull(userRepository.findByEmailID("p@gmail.com"));
	}
	
	
/*	@Test
	public void deleteFoodById()
	{
		foodRepository.deleteById(2156L);
		assertFalse(foodRepository.existsById(2156L));
	}
          */
}
