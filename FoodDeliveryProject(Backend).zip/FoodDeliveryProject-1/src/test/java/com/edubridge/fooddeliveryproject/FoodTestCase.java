package com.edubridge.fooddeliveryproject;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.edubridge.fooddeliveryproject.repository.FoodRepository;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class FoodTestCase {
	@Autowired
	FoodRepository foodRepository;

	@Test
	public void deleteFoodById()
	{
		foodRepository.deleteById(2156L);
		assertFalse(foodRepository.existsById(2156L));
	}
	
}
