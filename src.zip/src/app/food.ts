export class Food {
    constructor(
       public foodId: number,

       public foodName: string,

        public categoryId: number,

        public  price: number
    ) { }
         
   
}