
import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserControllerComponent } from './user-controller/user-controller.component';
import { CategoryControllerComponent } from './category-controller/category-controller.component';
import { FoodControllerComponent } from './food-controller/food-controller.component';
import { CartControllerComponent } from './cart-controller/cart-controller.component';
import { OrderControllerComponent } from './order-controller/order-controller.component';
import { AdminControllerComponent } from './admin-controller/admin-controller.component';
import { WelcomeControllerComponent } from './welcome-controller/welcome-controller.component';
import { ViewCategoryComponent } from './view-category/view-category.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AddCategoryComponent } from './add-category/add-category.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { ViewFoodComponent } from './view-food/view-food.component';
import { UpdateFoodComponent } from './update-food/update-food.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { UpdateCategoryComponent } from './update-category/update-category.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { UserFoodComponent } from './user-food/user-food.component';
import { CartDetailsComponent } from './cart-details/cart-details.component';
//import { Payment } from './payment';
import { PaymentComponent } from './payment/payment.component';
import { PaymentDetailsComponent } from './payment-details/payment-details.component';
const routes: Routes = [ {path:"", component:WelcomeControllerComponent},
  
{path:"register", component:UserControllerComponent},
{path:"add", component:CategoryControllerComponent},
{path: "viewcategory", component:ViewCategoryComponent},
{path: "addCategory", component:AddCategoryComponent},
{ path: 'register', component: AdminControllerComponent},
{ path: 'adminLogin', component: AdminControllerComponent},
{ path: 'adminhome', component: AdminHomeComponent},
{path: 'userDetails', component:UserDetailsComponent},
{path: 'welcomePage', component:WelcomeControllerComponent},
{path: 'foodController/:categoryId', component:FoodControllerComponent},
{path: 'viewFood', component:ViewFoodComponent},
{path:'updateFood/:foodId', component:UpdateFoodComponent},
{path: 'aboutUs', component:AboutUsComponent},
{path: 'contactUS', component:ContactUsComponent},
{path: 'updateCategory/:categoryId', component:UpdateCategoryComponent},
{path: 'userLogin', component: UserLoginComponent},
{path: 'userhome/:userEmailId', component:UserHomeComponent},
{path:'welcomepage', component:AdminHomeComponent},
{path: 'userfood/:categoryId/:userEmailId', component:UserFoodComponent},
//{path:'cartcontroller/:foodId/:userEmailId',component:CartControllerComponent },
{path: 'cartController/:foodId/:userEmailId', component:CartControllerComponent},
{path:'cartdetails/:userEmailId',component:CartDetailsComponent},
//{path: 'addToCart/:foodId',component:CartControllerComponent},
//{path: 'orderController',component:OrderControllerComponent},
{path:'removeFromCart/:cartId',component:CartDetailsComponent},
{path: 'orderitems/:userEmailId', component:OrderControllerComponent},
{path: 'payment/:orderId/:userEmailId', component:PaymentComponent},
{path: 'paymentdetails/:userEmailId',component:PaymentDetailsComponent},
//{path: 'payment/:orderId/:userEmailId', component:PaymentComponent}
{path: 'contactUs', component:ContactUsComponent},
{path:'welcomePage', component:PaymentDetailsComponent}
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
