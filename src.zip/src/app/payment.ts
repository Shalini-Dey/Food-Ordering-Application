export class Payment{
    constructor(
        public paymentId: number,
    
            public nameOnCard:string,

            public cardNumber:string,
            
            public cvv:number,
           
            public expYear:string,
            
            public totalPrice: number,
            
            public  paidDate :string
    ){

    }
}