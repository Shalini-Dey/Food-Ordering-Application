export class User {
    constructor (
        public emailID:string,

        public firstName: string,
        
        public lastName:string,

        public password: string,
        
        public district:string,

        public state: string,
        
        public zipCode:string,

        public mobile_No: string,
        
        public role:string,

        public street:string

    ) 
    {

    }
}