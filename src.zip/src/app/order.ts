export class Order {
    constructor(
        public orderId: number,

       // public cartId: number,

        public total: number

    ) {

    }
}