import { Component, OnInit } from '@angular/core';
import { Payment } from '../payment';
import { PaymentService } from '../payemnt.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-payment-details',
  templateUrl: './payment-details.component.html',
  styleUrls: ['./payment-details.component.css']
})
export class PaymentDetailsComponent implements OnInit{
  payment: Payment = new Payment(0,"","",0,"",0,"");
  paymentList:any;
  userEmailId:string="";
   constructor(private paymentService: PaymentService, private router:Router,private activatedRoute:ActivatedRoute) {}
   ngOnInit(): void {
    this.userEmailId = this.activatedRoute.snapshot.params["userEmailId"];
    console.log("inside OnInit")
    this.getPaymentByPaymentId();

  }
  private getPaymentByPaymentId() {
    let res = this.paymentService.getAllPaymentByUserEmailId(this.userEmailId);
    res.subscribe((data:any) =>{console.log(data), this.paymentList = data},
    error=>{console.log(error)}
    );
  }
 
  home()
  {
    this.router.navigate(['/usercategory', this.userEmailId]);
  }
  logOut()
{
  this.router.navigate(['/welcomePage'])
}
}
