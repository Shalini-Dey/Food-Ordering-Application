import { Component, OnInit } from '@angular/core';
import { Category } from '../category';
import { CategoryService } from '../category.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-category',
  templateUrl: './update-category.component.html',
  styleUrls: ['./update-category.component.css']
})
export class UpdateCategoryComponent implements OnInit{
  
    // food = new Food();
    category: Category = new Category(0," ");
     //categoryList:any;
     //message:any;
     categoryId:number=0;
     constructor(private categoryService: CategoryService, private router:Router,private activatedRoute:ActivatedRoute) { }
     ngOnInit(): void {
       console.log("inside OnInit")
       this.categoryId=this.activatedRoute.snapshot.params["categoryId"];
       this.categoryService. getCategoryId(this.categoryId).subscribe(data=>{this.category=data,console.log("back to controller"+this.category)},
       error=>console.log(error),
       )
       
     }
     updateCategory() {
     console.log("UpdateCategory");
     this.categoryService.updateCategory(this.categoryId,this.category).subscribe
     ((data:any)=> {console.log(data),
      alert ("updated Successfully"),
      this.router.navigate(['/viewcategory'])},
      error =>console.log("update Failed"),
     //this.message("Unable to Update Food. Try Again")
      )
   }

}
