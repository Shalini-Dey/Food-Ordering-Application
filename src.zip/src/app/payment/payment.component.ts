import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Payment } from '../payment';
import { PaymentService } from '../payemnt.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  payment: Payment = new Payment (0,"","",0,"",0,"");
  cartList:any;
  orderId:number=0;
   userEmailId:string="";
   constructor(private paymentService: PaymentService, private activatedRoute:ActivatedRoute,private router:Router) {}
   ngOnInit(): void {
     this.orderId = this.activatedRoute.snapshot.params["orderId"];
     this.userEmailId = this.activatedRoute.snapshot.params["userEmailId"];
     //console.log("inside OnInit")
    // let res = this.cartService.getAllCart();
   // res.subscribe((data:any) => this.cartList = data );
    }

   public confirm() {
    console.log("buttonclick");
    console.log(this.payment);
    let res=this.paymentService.addPayment(this.payment,this.orderId,this.userEmailId).subscribe((data:any)=> {console.log ("added")},
    error=>console.log(error));
    console.log(res);
    this.router.navigate(['/paymentdetails',this.userEmailId]);
   }
   back()
   {
    this.router.navigate(['/ordercontroller'])
   }
   home()
{
  this.router.navigate(['/userhome'])
}
   logOut()
{
  this.router.navigate(['/welcome'])
}
contactUs()
    {
      this.router.navigate(['/contact'])
    }
}
  

