import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Order } from './order';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http: HttpClient) {

   }
   public addOrder(order:Order, userEmailId:String): Observable<any>{
    console.log("service");
    console.log(order);
     return this.http.post<any>("http://localhost:8089/api/order/add/"+userEmailId, order,{responseType:'Text' as 'json'});
   }

   public getAllOrder(){
    console.log("inside Order Service");
    return this.http.get("http://localhost:8089/api/order");
   }
   public cancelOrder(orderId:number)
   {
    console.log("inside order Service - REMOVED");
    return this.http.delete("http://localhost:8089/api/order/"+orderId);
   }
   public getOrderByEmailId(userEmailId:String) {
    console.log("get Ordert By EmailId Service");
    return this.http.get("http://localhost:8089/api/order/user/"+userEmailId);
   }
   public getOrderById(orderId:number) {
    console.log("get Ordert By OrderId Service");
    return this.http.get("http://localhost:8089/api/order/"+orderId);
   }

}
