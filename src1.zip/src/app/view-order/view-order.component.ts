import { Component, OnInit } from '@angular/core';
import { OrderService } from '../order.service';
import { Order } from '../order';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-view-order',
  templateUrl: './view-order.component.html',
  styleUrls: ['./view-order.component.css']
})
export class ViewOrderComponent implements OnInit {
  order: Order = new Order(0, 0,);
  orderList:any;
  //userEmailId:String=" ";
  constructor(private orderService: OrderService,private activatedRoute:ActivatedRoute,private router:Router) {}
  ngOnInit(): void {
    console.log("inside OnInit")
    //this.userEmailId=this.activatedRoute.snapshot.params["userEmailId"];
     this.getAllOrder();
   
   }
public getAllOrder(){
  let res = this.orderService.getAllOrder();
  res.subscribe((data:any) =>{console.log(data), this.orderList = data},
  error=>{console.log(error)}
  );
}
}

