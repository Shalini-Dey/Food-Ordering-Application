import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-controller',
  templateUrl: './user-controller.component.html',
  styleUrls: ['./user-controller.component.css']
})
export class UserControllerComponent implements OnInit{

  user: User = new User("","","","","","","","","","");
  userList:any;
  message:any;
  constructor(private userService: UserService,private router :Router) {}
  ngOnInit(): void {
    console.log("inside OnInit")
    let res = this.userService.getAllUser();
   res.subscribe((data:any) => this.userList = data );
   }
    public registerUser() {
    console.log("buttonclick");
    console.log(this.user);
    let res=this.userService.registerUser(this.user).subscribe
    (
      data =>{console.log("Register success"), alert("User Register Successfull")
    this.router.navigate(['/userLogin'])},
    error =>{console.log("Register Failed"),console.log(error),
  
    this.message="Register failed.enter valid email and password"}
    ) 
   }
   back()
   {
    this.router.navigate(['/welcomePage']);
   }

}
