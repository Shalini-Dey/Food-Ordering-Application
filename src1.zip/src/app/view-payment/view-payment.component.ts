import { Component, OnInit } from '@angular/core';
import { Payment } from '../payment';
import { PaymentService } from '../payemnt.service';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-view-payment',
  templateUrl: './view-payment.component.html',
  styleUrls: ['./view-payment.component.css']
})
export class ViewPaymentComponent implements OnInit{
  payment: Payment = new Payment(0,"","",0,"",0,"");
  paymentList:any;
  userEmailId:string="";
  paymentId:number=0;
   constructor(private paymentService: PaymentService, private router:Router,private activatedRoute:ActivatedRoute) {}
   ngOnInit(): void {
    this.userEmailId = this.activatedRoute.snapshot.params["userEmailId"];
    console.log("inside OnInit")
    //this.getPaymentByuserEmailId();
    this.getPaymentList();

  }
  private getPaymentList() {
    let res = this.paymentService.getAllPayment();
    res.subscribe((data:any) => this.paymentList = data);
  }
  home()
  {
    this.router.navigate(['/usercategory',this.userEmailId]);
  }
}


